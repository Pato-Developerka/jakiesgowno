Config = {}

-- Prospecting blip
Config.ProspectingBlipText = "Miejsce poszukiwań"
Config.ProspectingBlipSprite = 485
